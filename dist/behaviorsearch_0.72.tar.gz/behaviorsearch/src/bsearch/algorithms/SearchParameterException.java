package bsearch.algorithms;

public class SearchParameterException extends Exception {

	private static final long serialVersionUID = 1L;

	public SearchParameterException(String msg) {
		super(msg);
	}

}
